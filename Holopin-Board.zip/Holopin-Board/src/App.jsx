import React from "react";

/**
 * HolopinBoard Component
 * Displays your Holopin board image linking to your profile
 */
const HolopinBoard = () => {
  const user = "sadiapeerzada";

  return (
    <div style={{ textAlign: "center", margin: "40px 0" }}>
      <a
        href={`https://holopin.io/@${user}`}
        target="_blank"
        rel="noopener noreferrer"
      >
        <img
          src={`https://holopin.me/${user}`}
          alt={`@${user}'s Holopin board`}
          style={{
            maxWidth: "100%",
            borderRadius: "15px",
            boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
            transition: "transform 0.2s ease",
          }}
          onMouseOver={(e) => (e.currentTarget.style.transform = "scale(1.05)")}
          onMouseOut={(e) => (e.currentTarget.style.transform = "scale(1)")}
        />
      </a>
    </div>
  );
};

export default HolopinBoard;

