import React from "react";
import HolopinBoard from "./HolopinBoard";

function App() {
  return (
    <div style={{ fontFamily: "sans-serif" }}>
      <h1 style={{ textAlign: "center", marginTop: "20px" }}>My Holopin Board</h1>
      <HolopinBoard />
    </div>
  );
}

export default App;
